package com.smo.persona;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonaApplicationTests {

	@Test
	void contextLoads() {
	}

}
